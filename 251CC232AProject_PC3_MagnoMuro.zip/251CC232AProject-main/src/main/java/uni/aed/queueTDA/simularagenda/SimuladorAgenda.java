
package uni.aed.queueTDA.simularagenda;
/**
 *
 * @author Renzo Magno
 */

import uni.aed.queueTDA.LinkedQueueTDA;
import uni.aed.queueTDA.PriorityQueueTDA;
import uni.aed.queueTDA.QueueEmptyExceptionTDA;
import uni.aed.queueTDA.QueueTDA;
import java.util.*;

/*
  Clase principal de simulación.
 */
public class SimuladorAgenda {
    private QueueTDA<Trabajo> cola;
    private Computadora computadora;
    private List<Trabajo> trabajosCompletados;
    private int minutos;
    private int capacidad;
    private boolean cargado = false;

    public SimuladorAgenda() {
        trabajosCompletados = new ArrayList<>();
    }

    public void cargar(int minutos, int capacidad) {
        this.minutos = minutos;
        this.capacidad = capacidad;
        this.cola = new PriorityQueueTDA<>(Comparator.comparingInt(t -> t.prioridad));
        this.computadora = new Computadora(capacidad);
        trabajosCompletados.clear();

        Random random = new Random();
        for (int minuto = 0; minuto < minutos; minuto++) {
            int prioridad = 1 + random.nextInt(5);
            int tiempoEjecucion = 1 + random.nextInt(10);
            Trabajo trabajo = new Trabajo(minuto, prioridad, tiempoEjecucion, minuto);
            cola.enqueue(trabajo);

            computadora.actualizar(minuto);
            while (computadora.puedeAgregar() && !cola.isEmpty()) {
                try {
                    Trabajo siguiente = cola.dequeue();
                    computadora.agregarTrabajo(siguiente, minuto);
                    trabajosCompletados.add(siguiente);
                } catch (QueueEmptyExceptionTDA e) {
                    break;
                }
            }
        }
        cargado = true;
    }

    public double tiempoEsperaPromedio() {
        if (!cargado) return 0;
        return trabajosCompletados.stream().mapToInt(Trabajo::tiempoEspera).average().orElse(0);
    }

    public int tiempoEsperaMaxPorPrioridad(int prioridad) {
        return trabajosCompletados.stream()
                .filter(t -> t.prioridad == prioridad)
                .mapToInt(Trabajo::tiempoEspera)
                .max().orElse(0);
    }

    public void eliminarAgenda() {
        trabajosCompletados.clear();
        cola = null;
        computadora = null;
        cargado = false;
    }

    public void visualizarAgenda() {
        if (!cargado) {
            System.out.println("No hay agenda cargada.");
            return;
        }
        trabajosCompletados.forEach(t ->System.out.printf("Trabajo #%d | Prioridad: %d | Espera: %d | Llegada: %d | Inicio: %d",
                        t.id, t.prioridad, t.tiempoEspera(), t.tiempoLlegada, t.tiempoInicio));
    }

    public static void main(String[] args) {
        SimuladorAgenda sim = new SimuladorAgenda();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("MENÚ AGENDA DE TRABAJO");
            System.out.println("1. Cargar agenda de trabajo");
            System.out.println("2. Obtener tiempo de espera promedio");
            System.out.println("3. Obtener tiempo de espera máximo por prioridad");
            System.out.println("4. Eliminar agenda de trabajo");
            System.out.println("5. Visualizar agenda de trabajo");
            System.out.println("6. Salir");
            System.out.print("Seleccione opción: ");
            int op = sc.nextInt();
            switch (op) {
                case 1 -> {
                    System.out.print("Minutos a simular: ");
                    int M = sc.nextInt();
                    System.out.print("Capacidad concurrente (N): ");
                    int N = sc.nextInt();
                    sim.cargar(M, N);
                    System.out.println("Agenda cargada.");
                }
                case 2 -> System.out.println("Tiempo de espera promedio: " + sim.tiempoEsperaPromedio());
                case 3 -> {
                    System.out.print("Ingrese prioridad (1-5): ");
                    int p = sc.nextInt();
                    System.out.println("Máximo tiempo de espera: " + sim.tiempoEsperaMaxPorPrioridad(p));
                }
                case 4 -> {
                    sim.eliminarAgenda();
                    System.out.println("Agenda eliminada.");
                }
                case 5 -> sim.visualizarAgenda();
                case 6 -> {
                    System.out.println("Fin del programa.");
                    return;
                }
                default -> System.out.println("Opción inválida.");
            }
        }
    }
}
