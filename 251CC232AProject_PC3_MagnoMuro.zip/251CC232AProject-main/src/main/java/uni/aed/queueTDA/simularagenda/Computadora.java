/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uni.aed.queueTDA.simularagenda;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Renzo Magno
 */

/*
 Representa la computadora que ejecuta trabajos concurrentemente.
 */
class Computadora {
    int capacidad;
    List<Trabajo> enEjecucion = new ArrayList<>();

    public Computadora(int capacidad) {
        this.capacidad = capacidad;
    }

    public void actualizar(int minuto) {
        enEjecucion.removeIf(t -> {t.tiempoEjecucion--;return t.tiempoEjecucion == 0;});
    }

    public boolean puedeAgregar() {
        return enEjecucion.size() < capacidad;
    }

    public void agregarTrabajo(Trabajo t, int minuto) {
        t.tiempoInicio = minuto;
        enEjecucion.add(t);
    }
}