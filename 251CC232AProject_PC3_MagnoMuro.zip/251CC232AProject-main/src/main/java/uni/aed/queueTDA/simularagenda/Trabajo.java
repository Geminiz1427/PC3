
package uni.aed.queueTDA.simularagenda;

/**
 *
 * Renzo Magno
 */

/*
 Representa un trabajo con prioridad y tiempo de ejecución.
 */
class Trabajo {
    int id;
    int prioridad; // 1 a 5, donde 1 es la más alta
    int tiempoEjecucion;
    int tiempoLlegada;
    int tiempoInicio = -1;

    public Trabajo(int id, int prioridad, int tiempoEjecucion, int tiempoLlegada) {
        this.id = id;
        this.prioridad = prioridad;
        this.tiempoEjecucion = tiempoEjecucion;
        this.tiempoLlegada = tiempoLlegada;
    }

    public int tiempoEspera() {
        return tiempoInicio == -1 ? 0 : tiempoInicio - tiempoLlegada;
    }
}
