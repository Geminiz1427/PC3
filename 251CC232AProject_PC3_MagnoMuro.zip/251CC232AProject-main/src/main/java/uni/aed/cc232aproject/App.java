/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package uni.aed.cc232aproject;

/**
 *
 * @author zemr
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
